import os
import random
import shutil
from itertools import islice

outputFolderPath = "Dataset/SplitData"
inputFolderPath = "Dataset/All"
classes = ["Fake", "Real"]

splitRatio = {"train": 0.7, "val": 0.2, "test": 0.1}

# Clear the output folder if it exists
if os.path.exists(outputFolderPath):
    shutil.rmtree(outputFolderPath)
    print("Directory is Removed")

# Create directories for train, val, and test sets
os.makedirs(f"{outputFolderPath}/train/images", exist_ok=True)
os.makedirs(f"{outputFolderPath}/train/labels", exist_ok=True)

os.makedirs(f"{outputFolderPath}/val/images", exist_ok=True)
os.makedirs(f"{outputFolderPath}/val/labels", exist_ok=True)

os.makedirs(f"{outputFolderPath}/test/images", exist_ok=True)
os.makedirs(f"{outputFolderPath}/test/labels", exist_ok=True)

# Get unique names from the list of file names
listNames = os.listdir(inputFolderPath)
uniqueNames = [os.path.splitext(name)[0] for name in listNames]
uniqueNames = list(set(uniqueNames))

# Shuffle the unique names list to improve model robustness
random.shuffle(uniqueNames)

# Calculate the number of files for each set
total_files = len(uniqueNames)
lenTrain = int(total_files * splitRatio['train'])
lenVal = int(total_files * splitRatio['val'])
lenTest = int(total_files * splitRatio['test'])

# While splitting, consider any remaining files
if lenTrain + lenVal + lenTest < total_files:
    lenTrain += total_files - (lenTrain + lenVal + lenTest)

# Split the list of unique names into train, val, and test sets
train_names = uniqueNames[:lenTrain]
val_names = uniqueNames[lenTrain:lenTrain + lenVal]
test_names = uniqueNames[lenTrain + lenVal:]

# Define the sequences for copying
sequences = {'train': train_names, 'val': val_names, 'test': test_names}

# Copy files to the respective directories
for sequence_name, name_list in sequences.items():
    for name in name_list:
        shutil.copy(f'{inputFolderPath}/{name}.jpg', f'{outputFolderPath}/{sequence_name}/images/{name}.jpg')
        shutil.copy(f'{inputFolderPath}/{name}.txt', f'{outputFolderPath}/{sequence_name}/labels/{name}.txt')

print("Splitting files is Completed")

# Create a data.yaml file
dataYaml = f'path: ../Dataset/SplitData\n\
train: ../train/images\n\
val: ../val/images\n\
test: ../test/images\n\
\n\
nc: {len(classes)}\n\
names: {classes}'

with open(f"{outputFolderPath}/data.yaml", 'w') as f:
    f.write(dataYaml)

print("data.yaml file created.")
