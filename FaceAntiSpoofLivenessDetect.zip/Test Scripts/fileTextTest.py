f = open('test.txt','a')
f.write('This is new line\n')
f.close()