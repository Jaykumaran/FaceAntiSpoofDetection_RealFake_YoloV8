import cvzone
from cvzone.FaceDetectionModule import FaceDetector
import cv2
from time import time

# Initialize the webcam
# usually 0 refers to the built-in webcam
classID = 1 # 0 is Fake ; 1 is Real
offsetPercentageW = 10 #10 percent
offsetPercentageH = 20
confidence = 0.8
floatingPoint = 6
save = True
blurThreshold = 35 #larger means in good focus
outputDirPath = 'Dataset/Real'
debug = False

cap = cv2.VideoCapture(0)
camWidth,camHeight = 640,480
cap.set(3,camWidth)
cap.set(4,camHeight)

# Initialize the FaceDetector object

detector = FaceDetector(minDetectionCon=0.5, modelSelection=0)

# Run the loop to continually get frames from the webcam
while True:
    # Read the current frame from the webcam
    # success: Boolean, whether the frame was successfully grabbed
    # img: the captured frame
    success, img = cap.read()
    imgOutput = img.copy()

    # Detect faces in the image
    # img: Updated image
    # bboxs: List of bounding boxes around detected faces
    img, bboxs = detector.findFaces(img, draw=False)\

    #resets every iteration
    BlurinessList = []  #contain boolean values to represent whether blur or not for multiple faces like [True,False,True] if second person is in Focus
    listInfo = []   #Normalised values and class name for the label txt file for multiple faces


    # Check if any face is detected
    if bboxs:
        # Loop through each bounding box
        for bbox in bboxs:
            # bbox contains 'id', 'bbox', 'score', 'center'

            # ---- Get Data  ---- #
            center = bbox["center"]
            x, y, w, h = bbox['bbox']
            # check conf score

            score = bbox['score'][0]
            if score > confidence:

                #Adding Offsets
                offsetW = (offsetPercentageW/100)*w
                x = int(x - offsetW)
                w = int(w + offsetW *2)

                offsetH = (offsetPercentageH/100)*h
                y = int(y - offsetH * 3)
                h = int(h + offsetH * 3.5)

                # To avoid values less than 1
                if x < 0: x=0
                if y < 0: y=0
                if w < 0: w=0
                if h < 0: h=0

            #Find Bluriness in face
                imgFace = img[y:y+h,x:x+w]
                cv2.imshow("FaceDemo",imgFace)
                blurValue = int(cv2.Laplacian(imgFace,cv2.CV_64F).var())
                if blurValue > blurThreshold:
                    BlurinessList.append(True)
                else:
                    BlurinessList.append(False)

            #Normalise Values

                ih, iw, _ = img.shape
                xc,yc = x+w/2,y+h/2
                xcn,ycn = round(xc / iw ,floatingPoint),round(yc/ih,floatingPoint)
                wn,hn = round(w / iw ,floatingPoint),round(h/ih,floatingPoint)
                print(xcn,ycn,wn,hn)

                # To avoid values above 1
                if xcn > 1: xcn = 1
                if ycn > 1: ycn = 1
                if wn > 1: wn = 1
                if hn > 1: hn = 1

                #For Yolo Labeling Annoatation
                listInfo.append(f"{classID} {xcn} {ycn} {wn} {hn}\n") #new line is created for each class record

                cvzone.putTextRect(imgOutput, f'{int(score*100)}% Blur:{blurValue}', (x, y - 10),scale=1,thickness=2)
                cvzone.cornerRect(imgOutput, (x, y, w, h))

                #To detect threshold we use debug
                if debug:
                    cvzone.putTextRect(img, f'{int(score * 100)}% Blur:{blurValue}', (x, y - 10), scale=1,
                                       thickness=2)
                    cvzone.cornerRect(img, (x, y, w, h))


    if save:
        if all(BlurinessList) and  BlurinessList != []:
          #save img
          #To avoid  float value in img name
          timeNow = time()
          timeNow = str(timeNow).split('.')
          timeNow = timeNow[0] + timeNow[1]
          cv2.imwrite(f"{outputDirPath}/{timeNow}.jpg",img) #while saving we no need to save with bbox..so a copy is created

        #save corresponding Label file as a Auto Annotation
        for info in listInfo:
            f = open(f"{outputDirPath}/{timeNow}.txt", 'a')
            f.write(info)  #creates individul record for each face in a single frame even if multiple faces detected
            f.close()

    # Display the image in a window named 'Image'
    cv2.imshow("Image", imgOutput)
    # Wait for 1 millisecond, and keep the window open
    cv2.waitKey(1)
