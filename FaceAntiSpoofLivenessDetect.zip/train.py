#Offline Training (Not recommended for low end spec PC)
from ultralytics import YOLO

model = YOLO('yolon.pt')



def main():
    model.train(data = 'Dataset/SplitData/data.yaml',epochs = 200)


if __name__ == '__main__':

    main()